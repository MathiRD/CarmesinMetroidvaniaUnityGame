using UnityEngine;
using UnityEngine.SceneManagement;

namespace Metroidvania
{
    public class ChangeScene : MonoBehaviour
    {
        // Nome da cena que voc� quer carregar
        public string ThePaleMoonlight_Sample;

        // Esse m�todo ser� chamado pelo bot�o
        public void CarregarCena()
        {
            if (!string.IsNullOrEmpty(ThePaleMoonlight_Sample))
            {
                SceneManager.LoadScene(ThePaleMoonlight_Sample);
            }
            else
            {
                Debug.LogError("Nome da cena n�o definido no componente BotaoTrocarCena!");
            }
        }
    }
}
