using UnityEngine;

namespace Metroidvania.Characters.Knight
{
    [CreateAssetMenu(fileName = "ArcherData", menuName = "Scriptables/Characters/Archer Data")]
    public class ArcherData : ScriptableObject
    {
    }
}
